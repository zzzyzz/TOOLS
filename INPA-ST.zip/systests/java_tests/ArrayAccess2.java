public class ArrayAccess2 {

	public static void main(String[] args) {
		int [] a = new int[7];
		a[0] = 0;
		for (int i = 1; i < 7; i++){
			a[i] = i;
		}
	}
}
