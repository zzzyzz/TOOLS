public class ArrayInitNested {

    public static void main (String [] args) {
    
        int [][] a = { {1, 2}, {3, 4}};
    }
}
