public class AssignStmts {

    public static void main (String [] args){
        run();
    }

    
    public static void run(){
    
        int x = 9;
        int y = 10;
        int z = 0;

        z += y;

        z -= x;
    }
        
}
