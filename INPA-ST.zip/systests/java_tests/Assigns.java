public class Assigns {

    public static void main(String [] args) {
        int side;
        int otherside;
        int plycnt = 7;
        
        side = (otherside = plycnt & 1) ^ 1;   
    }
}
