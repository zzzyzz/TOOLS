public class AttrTest {

    public static void main (String [] args) {
        AttrTest at = new AttrTest();
        at.run("Hello");
    }

    private void run(java.lang.String h){
    }
} 
