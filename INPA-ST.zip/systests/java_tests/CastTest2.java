public class CastTest2 {

    public static void main(String [] args){
        int i = (int)0L; 
    }
}
