public class Casts {

    public long number = 0;
	public static void main(String[] args) {
        long l1 = 0;	
		long l = 10L;
		int i = (int)l;
	}
}
