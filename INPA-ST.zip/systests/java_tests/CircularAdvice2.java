public class CircularAdvice2 {
    public static void main(String[] args) {
        m(5);
    }

    public static long m(long l) {
        return -1;
    }
}

