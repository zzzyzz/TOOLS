public class Complex {

    public static void main(String [] args){
        int [] a = new int [] { 2,3,4,5,3,3,4,3,2};
        int x = 9;
        int y = 3;
        int z = 4;

        System.out.println(a[x=y=z]);
    }
}
