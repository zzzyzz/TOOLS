public class CondOrTest {

    public static void main(String [] args) {
    
        boolean x = true;
        boolean y = false;

        if (x || y) {
            System.out.println("Both True");
        }
    }
}
