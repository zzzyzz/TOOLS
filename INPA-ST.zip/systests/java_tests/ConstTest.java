public class ConstTest {

    public static void main(String [] args){
        ConstTest ct = new ConstTest();
        ct.run();
    }
    
    public static final int x = 1+1;

    public void run(){
        switch(x){
        }
        char c = 'c';
    }
}
