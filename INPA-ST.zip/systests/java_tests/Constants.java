public class Constants {
    
    public static void main (String [] args) {
        int i = 3 + 4 + 5 + 7;
        int j = -(3 + 4);
        System.out.println(i);
        System.out.println(j);
        int [] arr = new int [] {3, 4, 5, 4, 5, 8, 4};
        System.out.println(arr[1+1+1]);
        System.out.println(!false);
        switches(1+4+5);
    }

    public static void switches(int i){
        switch (i){
            
            case 3+7: {System.out.println(10); break;}
        }
    }
}
