public class FieldFloats {

    protected static final double XX = -7.09E2;
    protected static final float FF = -7.0F;
    protected final double YY = 7.09E2;
    
    public static void main(String [] args){
        System.out.println(new FieldFloats().XX);
    }
}
