public class FieldInits {
    long bits;
    int i = 9;
    
    public FieldInits(){
        bits = 8L;
    }

    public static void main(String [] args) {
        FieldInits fi = new FieldInits();
    }
}
