public class FieldTypes {

    private long l = 9;
    private int u = 0;

    public static void main(String [] args){
        FieldTypes ft = new FieldTypes();
        ft.run();
    }
    
    public void run(){
        long g = 9;
        l = 2;
    }
}
