class Foo {
    public static void main(String [] agrs){
        Foo f = new Foo();
        f.sum(new int [] {2,3,4,2,3,3,21,3});
    }
    
  public void sum(int[] a) {
	int total = 0;
	int i=0;
	int b = a[0];
	String j = null;

	for (i=0; i<a.length; i++) {
	  total += a[i];
	}
	System.out.println(j);
	int c = a[i-1];
  }
}
