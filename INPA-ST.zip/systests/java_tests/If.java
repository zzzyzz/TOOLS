public class If {

    public static void main(String [] args){
        boolean x = false;
        boolean y = true;

        if (y && true){
            System.out.println(y);
        }
    }
}
