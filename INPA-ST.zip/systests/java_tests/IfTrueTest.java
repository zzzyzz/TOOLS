public class IfTrueTest {

    public static void main(String [] args){
        
        int x = 0;

        if (true) {
            x = 8;
        }
        else {
            x = 9;
        }
    }
}
