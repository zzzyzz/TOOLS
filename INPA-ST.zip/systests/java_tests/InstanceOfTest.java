public class InstanceOfTest {

    public static void main(String [] args) {
        Object o = new Integer(9);
        if (o instanceof Integer) {
            int i = 0;
        }
    }
}
