public class IntAssign {

    public static void main(String [] args){
        System.out.println(""+Integer.MIN_VALUE+0);
        System.out.println(0-Integer.MIN_VALUE);
    }
}
