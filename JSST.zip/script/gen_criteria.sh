#!/bin/sh

root_project_cyg=/cygdrive/E/projects/eclipse/slicer4j.slicer
root_project_win=E:/projects/eclipse/slicer4j.slicer

subject=jtcas

version=1

test_s=1

test_e=1608

cri_orig=t_1

path_input_cyg=${root_project_cyg}/input
path_input_win=${root_project_win}/input
path_ip_criteria_cyg=${path_input_cyg}/criteria
path_ip_criteria_win=${path_input_win}/criteria
path_ip_cri_sub_cyg=${path_ip_criteria_cyg}/${subject}
path_ip_cri_sub_win=${path_ip_criteria_win}/${subject}
path_ip_cri_ver_cyg=${path_ip_cri_sub_cyg}/v_${version}
path_ip_cri_ver_win=${path_ip_cri_sub_win}/v_${version}
path_ip_cri_temp_cyg=${path_ip_cri_sub_cyg}/temp
path_ip_cri_temp_win=${path_ip_cri_sub_win}/temp


for ((i_test=${test_s};i_test<=${test_e};i_test++))
do
	if [ $((${i_test}%20)) -eq 0 ]; then
		echo "gen criteria of test ${i_test}"
	fi

	cp -r ${path_ip_cri_ver_cyg}/${cri_orig} ${path_ip_cri_temp_cyg}
	rename ${cri_orig} t_${i_test} ${path_ip_cri_temp_cyg}/${cri_orig}
	mv -f ${path_ip_cri_temp_cyg}/t_${i_test} ${path_ip_cri_ver_cyg}
done