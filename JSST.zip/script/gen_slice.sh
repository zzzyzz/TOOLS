#!/bin/sh

root_project_cyg=/cygdrive/E/projects/eclipse/slicer4j.slicer
root_project_win=E:/projects/eclipse/slicer4j.slicer

subject=print_tokens

version=1

test_s=1

test_e=4140

slice_orig=t_1

path_output_cyg=${root_project_cyg}/output
path_output_win=${root_project_win}/output
path_op_sub_cyg=${path_output_cyg}/${subject}
path_op_sub_win=${path_output_win}/${subject}
path_op_ver_cyg=${path_op_sub_cyg}/v_${version}
path_op_ver_win=${path_op_sub_win}/v_${version}


for ((i_test=${test_s};i_test<=${test_e};i_test++))
do
	if [ ${i_test} -eq 1 ]; then
		continue
	fi

	if [ $((${i_test}%20)) -eq 0 ]; then
		echo "gen criteria of test ${i_test}"
	fi

	path_op_test_cyg=${path_op_ver_cyg}/t_${i_test}
	path_op_test_win=${path_op_ver_win}/t_${i_test}

	if [ ! -d ${path_op_test_cyg} ]; then 
	    mkdir ${path_op_test_cyg}
	fi

	cp -r ${path_op_ver_cyg}/${slice_orig}/* ${path_op_test_cyg}

done



